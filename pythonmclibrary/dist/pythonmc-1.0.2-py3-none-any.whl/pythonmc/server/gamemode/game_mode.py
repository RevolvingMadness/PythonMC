class GameMode:
	id = None
	name = None
	SURVIVAL = None
	CREATIVE = None
	ADVENTURE = None
	SPECTATOR = None
