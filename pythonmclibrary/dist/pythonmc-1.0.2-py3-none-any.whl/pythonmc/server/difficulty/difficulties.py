class Difficulties:
	EASY = None
	HARD = None
	NORMAL = None
	PEACEFUL = None
