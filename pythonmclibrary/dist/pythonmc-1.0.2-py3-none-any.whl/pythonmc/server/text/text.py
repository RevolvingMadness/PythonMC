class Text:
	message = None

	def __init__(self, message):
		def withFormatting(self, formatting): ...
