class RemovalReasons:
	KILLED = None
	DISCARDED = None
	UNLOADED_TO_CHUNK = None
	UNLOADED_WITH_PLAYER = None
	CHANGED_DIMENSION = None
