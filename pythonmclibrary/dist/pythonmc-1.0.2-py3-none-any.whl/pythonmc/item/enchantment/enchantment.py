class Enchantment:
	level = None
	rarity = None
