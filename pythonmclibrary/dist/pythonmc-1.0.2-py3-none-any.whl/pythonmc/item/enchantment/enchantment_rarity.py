class EnchantmentRarity:
	COMMON = None
	UNCOMMON = None
	RARE = None
	VERY_RARE = None
