class Item:
	name = None

	def __init__(self, item):
