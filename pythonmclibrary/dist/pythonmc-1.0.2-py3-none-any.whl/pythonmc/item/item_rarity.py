class ItemRarity:
	COMMON = None
	UNCOMMON = None
	RARE = None
	EPIC = None
