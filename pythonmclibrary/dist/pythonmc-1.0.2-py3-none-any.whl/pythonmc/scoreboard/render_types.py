class RenderTypes:
	INTEGER = None
	HEARTS = None
