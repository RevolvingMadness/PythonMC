class Worlds:
	OVERWORLD = None
	NETHER = None
	END = None
