class BlockState:
	block = None

	def __init__(self, block): ...

	@staticmethod
	def isOf(block): ...
