class Vec2f:
	x = None
	y = None

	def __init__(self, x, y):
		...
