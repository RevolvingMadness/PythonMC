class Vec3d:
	x = None
	y = None
	z = None

	def __init__(self, x, y, z):
		...
