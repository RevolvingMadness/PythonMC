class Weather:
	CLEAR = None
	RAIN = None
	THUNDER = None
