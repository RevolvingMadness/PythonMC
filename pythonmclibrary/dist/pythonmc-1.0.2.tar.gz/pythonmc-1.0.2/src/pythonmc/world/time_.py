class Time:
	DAY = None
	MIDNIGHT = None
	NIGHT = None
	NOON = None
