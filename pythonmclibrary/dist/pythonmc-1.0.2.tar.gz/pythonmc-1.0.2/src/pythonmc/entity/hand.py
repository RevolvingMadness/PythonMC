class Hand:
	MAIN_HAND = None
	OFF_HAND = None
