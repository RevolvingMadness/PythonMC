class StatusEffectInstance:
	duration = None
	amplifier = None
