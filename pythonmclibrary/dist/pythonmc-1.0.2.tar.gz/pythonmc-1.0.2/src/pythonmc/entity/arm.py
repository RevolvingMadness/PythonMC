class Arm:
	LEFT = None
	RIGHT = None
