class GameModes:
	SURVIVAL = None
	CREATIVE = None
	ADVENTURE = None
	SPECTATOR = None
