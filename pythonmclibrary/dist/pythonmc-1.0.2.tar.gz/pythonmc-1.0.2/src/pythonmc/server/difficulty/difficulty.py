class Difficulty:
	name = None
	id = None
	info = None
