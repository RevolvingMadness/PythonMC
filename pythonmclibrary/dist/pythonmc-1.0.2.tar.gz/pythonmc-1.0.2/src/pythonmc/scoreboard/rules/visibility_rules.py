class VisibilityRules:
	ALWAYS = None
	NEVER = None
	HIDE_FOR_OTHER_TEAMS = None
	HIDE_FOR_OWN_TEAM = None
