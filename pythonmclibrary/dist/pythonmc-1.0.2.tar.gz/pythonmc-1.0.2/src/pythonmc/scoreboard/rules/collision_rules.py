class CollisionRules:
	ALWAYS = None
	NEVER = None
	PUSH_OTHER_TEAMS = None
	PUSH_OWN_TEAM = None
