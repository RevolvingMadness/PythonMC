class BlockPos:
	x = None
	y = None
	z = None

	def __init__(self, x, y, z):
		...
