class Block:
	item = None
	name = None
	blastResistance = None
	velocityMultiplier = None
	jumpVelocityMultiplier = None
	slipperiness = None

	def __init__(self, block):
		...
