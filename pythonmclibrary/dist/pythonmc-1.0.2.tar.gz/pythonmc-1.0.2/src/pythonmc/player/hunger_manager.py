class HungerManager:
	exhaustion = None
	foodLevel = None
	saturationLevel = None
