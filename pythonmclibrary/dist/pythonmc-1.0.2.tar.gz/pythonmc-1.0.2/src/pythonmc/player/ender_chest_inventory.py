class EnderChestInventory:
	stacks = None
