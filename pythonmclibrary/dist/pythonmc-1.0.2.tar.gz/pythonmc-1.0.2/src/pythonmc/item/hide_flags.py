class HideFlags:
	ENCHANTMENTS = None
	MODIFIERS = None
	UNBREAKABLE = None
	CAN_DESTROY = None
	CAN_PLACE = None
	ADDITIONAL = None
	DYE = None
	UPGRADES = None
